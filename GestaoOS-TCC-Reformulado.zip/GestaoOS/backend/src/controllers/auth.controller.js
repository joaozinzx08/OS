import * as auth from '../services/auth.service.js';
import { Empresa, publicUser } from '../models/index.js';
import { cookieName, cookieOptions } from '../middlewares/auth.js';
import { env } from '../config/env.js';
export async function login(req, res) {
  const { token, ...data } = await auth.login(req.data);
  res.cookie(cookieName, token, { ...cookieOptions, maxAge: env.sessionHours * 3600000 });
  res.json(data);
}
export async function me(req, res) {
  const company = await Empresa.findByPk(req.user.empresaId);
  res.json({ usuario: publicUser(req.user), empresa: { id: company.id, nome: company.nome } });
}
export async function logout(req, res) {
  await auth.logout(req.user, req.sessionId);
  res.clearCookie(cookieName, cookieOptions).status(204).end();
}
export async function profile(req, res) {
  const user = await auth.updateProfile(req.user, req.data);
  if (req.data.novaSenha) res.clearCookie(cookieName, cookieOptions);
  res.json({ usuario: user, loginNecessario: !!req.data.novaSenha });
}
