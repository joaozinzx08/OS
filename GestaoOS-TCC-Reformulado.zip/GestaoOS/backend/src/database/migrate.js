import { db, connect, write } from './connection.js';
import * as initial from './migrations/001-initial.js';
export async function migrate() {
  await connect();
  await db.query('CREATE TABLE IF NOT EXISTS migrations (name TEXT PRIMARY KEY, appliedAt TEXT NOT NULL)');
  for (const migration of [initial]) {
    await write(async transaction => {
      const [rows] = await db.query('SELECT name FROM migrations WHERE name = :name', { replacements: { name: migration.name }, transaction });
      if (rows.length) return;
      await migration.up(db, transaction);
      await db.query('INSERT INTO migrations(name, appliedAt) VALUES (:name, :date)', {
        replacements: { name: migration.name, date: new Date().toISOString() }, transaction });
    });
  }
}
