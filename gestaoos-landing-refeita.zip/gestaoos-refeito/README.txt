GESTÃOOS — LANDING REFEITA

Arquivos:
- LandingPage.jsx
- LandingPage.css

Onde colocar no projeto reestruturado:
frontend/src/pages/LandingPage.jsx
frontend/src/pages/LandingPage.css

O LandingPage.jsx já importa ./LandingPage.css.
No App.jsx, mantenha:
import LandingPage from "./pages/LandingPage";
<Route path="/" element={<LandingPage />} />

Conceito preservado do legado:
- plataforma de ordens de serviço empresarial
- ambiente multiempresa
- organização por setores
- prioridade e SLA
- fluxo completo da OS
- quatro perfis: administrador principal, administrador de setor, gestor e colaborador
- histórico e auditoria

Adaptação para o reestruturado:
- visual clean azul/branco/cinza
- sem emojis
- uma landing pública única, em vez de várias páginas institucionais separadas
- CTA principal apenas para login, sem recriar o antigo fluxo público de criação de empresa
- não apresenta chat, kanban, calendário e exportações como funcionalidades atuais
