import { Link } from "react-router-dom";
import "./LandingPage.css";

const setores = [
  "RH",
  "Administração",
  "Documentação Técnica",
  "Produção",
  "Qualidade",
  "TI / Sistemas",
  "Manutenção",
  "Financeiro",
  "Compras",
  "Logística",
];

const fluxo = [
  ["01", "Abertura", "O colaborador registra a solicitação com setor, categoria, prioridade e descrição."],
  ["02", "Classificação", "A ordem é organizada por categoria, prioridade e prazo para facilitar a triagem."],
  ["03", "Encaminhamento", "A demanda chega ao setor responsável com contexto e histórico centralizados."],
  ["04", "Atendimento", "Gestores acompanham, atualizam o status e registram as ações realizadas."],
  ["05", "Acompanhamento", "Solicitante e equipe visualizam a evolução da OS sem depender de mensagens soltas."],
  ["06", "Conclusão", "A ordem é encerrada com histórico preservado para consulta, indicadores e auditoria."],
];

const perfis = [
  ["AP", "Administrador principal", "Visão completa da empresa, usuários, setores, ordens e auditoria."],
  ["AS", "Administrador de setor", "Administração limitada aos setores e responsabilidades autorizados."],
  ["GE", "Gestor", "Atendimento das ordens do setor, atualização de status e acompanhamento de prazos."],
  ["CO", "Colaborador", "Abertura e acompanhamento das próprias solicitações internas."],
];

export default function LandingPage() {
  return (
    <div className="go-landing">
      <header className="go-header">
        <div className="go-shell go-header__inner">
          <Link className="go-brand" to="/" aria-label="GestãoOS - início">
            <span className="go-brand__mark" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="none">
                <path d="M7 5.75h7.5M7 10h5M7 14.25h4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
                <path d="M15.7 13.4a3.1 3.1 0 1 0 0 6.2 3.1 3.1 0 0 0 0-6.2Z" stroke="currentColor" strokeWidth="1.8" />
                <path d="m14.45 16.5.8.8 1.7-1.85" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M5.75 3.75h9.5A2.75 2.75 0 0 1 18 6.5v5.1M5.75 3.75A2.75 2.75 0 0 0 3 6.5v11A2.75 2.75 0 0 0 5.75 20.25h5.7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
              </svg>
            </span>
            <span className="go-brand__text">
              <strong>GestãoOS</strong>
              <small>Ordens de serviço empresariais</small>
            </span>
          </Link>

          <nav className="go-nav" aria-label="Navegação principal">
            <a href="#plataforma">Plataforma</a>
            <a href="#fluxo">Fluxo</a>
            <a href="#perfis">Perfis</a>
            <a href="#seguranca">Segurança</a>
          </nav>

          <Link className="go-button go-button--small" to="/login">
            Acessar sistema
          </Link>
        </div>
      </header>

      <main>
        <section className="go-hero" id="inicio">
          <div className="go-shell go-hero__grid">
            <div className="go-hero__content">
              <span className="go-eyebrow">Gestão de ordens de serviço empresarial</span>
              <h1>
                Solicitações internas organizadas do início à conclusão.
              </h1>
              <p className="go-hero__lead">
                O GestãoOS centraliza demandas da empresa, encaminha cada ordem ao setor responsável
                e mantém prazos, responsáveis, status e histórico no mesmo lugar.
              </p>

              <div className="go-hero__actions">
                <Link className="go-button" to="/login">
                  Acessar sistema
                  <span aria-hidden="true">→</span>
                </Link>
                <a className="go-button go-button--ghost" href="#fluxo">
                  Ver como funciona
                </a>
              </div>

              <div className="go-hero__proof" aria-label="Principais características">
                <div>
                  <strong>Multiempresa</strong>
                  <span>Dados isolados por empresa</span>
                </div>
                <div>
                  <strong>Por setores</strong>
                  <span>Responsabilidades bem definidas</span>
                </div>
                <div>
                  <strong>Rastreável</strong>
                  <span>Histórico e auditoria</span>
                </div>
              </div>
            </div>

            <div className="go-workspace" aria-label="Prévia conceitual do GestãoOS">
              <div className="go-workspace__topbar">
                <div>
                  <span className="go-workspace__brand-dot" />
                  <strong>GestãoOS</strong>
                </div>
                <span className="go-workspace__company">Empresa Alpha</span>
              </div>

              <div className="go-workspace__body">
                <aside className="go-workspace__sidebar" aria-hidden="true">
                  <span className="is-active">Painel</span>
                  <span>Ordens</span>
                  <span>Usuários</span>
                  <span>Setores</span>
                  <span>Auditoria</span>
                </aside>

                <div className="go-workspace__main">
                  <div className="go-workspace__heading">
                    <div>
                      <small>Visão geral</small>
                      <h2>Ordens de serviço</h2>
                    </div>
                    <span className="go-workspace__pill">Hoje</span>
                  </div>

                  <div className="go-kpis">
                    <div><span>Abertas</span><strong>18</strong></div>
                    <div><span>Em atendimento</span><strong>09</strong></div>
                    <div><span>Concluídas</span><strong>42</strong></div>
                  </div>

                  <div className="go-queue">
                    <div className="go-queue__head">
                      <span>Ordem</span>
                      <span>Setor</span>
                      <span>Prioridade</span>
                      <span>Status</span>
                    </div>
                    <div className="go-queue__row">
                      <strong>#OS-1048</strong>
                      <span>Manutenção</span>
                      <span className="go-tag go-tag--urgent">Urgente</span>
                      <span className="go-status go-status--working">Em atendimento</span>
                    </div>
                    <div className="go-queue__row">
                      <strong>#OS-1047</strong>
                      <span>TI / Sistemas</span>
                      <span className="go-tag">Alta</span>
                      <span className="go-status">Encaminhada</span>
                    </div>
                    <div className="go-queue__row">
                      <strong>#OS-1046</strong>
                      <span>RH</span>
                      <span className="go-tag go-tag--medium">Média</span>
                      <span className="go-status go-status--done">Concluída</span>
                    </div>
                  </div>

                  <div className="go-workspace__footerline">
                    <span><i className="go-signal" /> SLA monitorado</span>
                    <span>Histórico preservado</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="go-section" id="plataforma">
          <div className="go-shell">
            <div className="go-section__heading go-section__heading--split">
              <div>
                <span className="go-eyebrow">A plataforma</span>
                <h2>O conceito do legado, agora com uma interface mais limpa.</h2>
              </div>
              <p>
                Nada de transformar o GestãoOS em outro produto: a base continua sendo centralização de
                solicitações, setores, prioridades, responsáveis, prazos e rastreabilidade dentro da empresa.
              </p>
            </div>

            <div className="go-feature-grid">
              <article className="go-feature-card">
                <span className="go-feature-card__code">OS</span>
                <h3>Ordens centralizadas</h3>
                <p>Demandas deixam de ficar espalhadas entre conversa, papel e mensagens isoladas.</p>
              </article>
              <article className="go-feature-card">
                <span className="go-feature-card__code">SET</span>
                <h3>Gestão por setores</h3>
                <p>Cada solicitação é encaminhada à área responsável e acompanha o fluxo correto.</p>
              </article>
              <article className="go-feature-card">
                <span className="go-feature-card__code">SLA</span>
                <h3>Prazos e prioridade</h3>
                <p>Urgência, prazo e situação ficam visíveis para evitar atendimento perdido ou atrasado.</p>
              </article>
              <article className="go-feature-card">
                <span className="go-feature-card__code">LOG</span>
                <h3>Histórico e auditoria</h3>
                <p>As movimentações importantes permanecem registradas para consulta e rastreabilidade.</p>
              </article>
            </div>
          </div>
        </section>

        <section className="go-section go-section--soft" id="fluxo">
          <div className="go-shell">
            <div className="go-section__heading">
              <span className="go-eyebrow">Fluxo da ordem</span>
              <h2>Uma solicitação com começo, responsável e conclusão.</h2>
              <p>
                O fluxo original do GestãoOS continua sendo o centro do sistema: registrar, organizar,
                encaminhar, atender, acompanhar e concluir.
              </p>
            </div>

            <div className="go-flow-grid">
              {fluxo.map(([number, title, description]) => (
                <article className="go-flow-card" key={number}>
                  <span>{number}</span>
                  <h3>{title}</h3>
                  <p>{description}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="go-section" id="perfis">
          <div className="go-shell go-two-column">
            <div className="go-section__heading go-section__heading--sticky">
              <span className="go-eyebrow">Acesso por perfil</span>
              <h2>Cada pessoa enxerga o que precisa para trabalhar.</h2>
              <p>
                O GestãoOS mantém os quatro níveis do projeto legado, com permissões separadas e escopo
                coerente com a responsabilidade de cada usuário.
              </p>
            </div>

            <div className="go-role-list">
              {perfis.map(([initials, title, description]) => (
                <article className="go-role" key={initials}>
                  <span className="go-role__badge">{initials}</span>
                  <div>
                    <h3>{title}</h3>
                    <p>{description}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="go-section go-section--dark" id="seguranca">
          <div className="go-shell go-security">
            <div>
              <span className="go-eyebrow go-eyebrow--dark">Estrutura empresarial</span>
              <h2>Separação por empresa e controle por permissão.</h2>
              <p>
                O sistema foi pensado para ambientes corporativos: usuários pertencem a uma empresa,
                acessos dependem do perfil e ações relevantes podem ser rastreadas.
              </p>
            </div>

            <div className="go-security__list">
              <div><strong>01</strong><span>Isolamento de dados por empresa</span></div>
              <div><strong>02</strong><span>Autenticação e rotas protegidas</span></div>
              <div><strong>03</strong><span>Permissões por função e setor</span></div>
              <div><strong>04</strong><span>Registro de histórico e auditoria</span></div>
            </div>
          </div>
        </section>

        <section className="go-section" id="setores">
          <div className="go-shell">
            <div className="go-section__heading">
              <span className="go-eyebrow">Organização interna</span>
              <h2>Preparado para diferentes áreas da empresa.</h2>
              <p>Os setores podem ser organizados de acordo com a estrutura de cada empresa.</p>
            </div>

            <div className="go-sector-list">
              {setores.map((setor) => <span key={setor}>{setor}</span>)}
            </div>
          </div>
        </section>

        <section className="go-cta">
          <div className="go-shell">
            <div className="go-cta__box">
              <div>
                <span className="go-eyebrow">GestãoOS</span>
                <h2>Entre no ambiente da sua empresa.</h2>
                <p>Acesse suas ordens, acompanhe atendimentos e utilize as funções liberadas para o seu perfil.</p>
              </div>
              <Link className="go-button go-button--light" to="/login">
                Fazer login
                <span aria-hidden="true">→</span>
              </Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="go-footer">
        <div className="go-shell go-footer__inner">
          <div>
            <strong>GestãoOS</strong>
            <span>Gestão de ordens de serviço empresariais</span>
          </div>
          <p>TCC 2026 · Sistema de gestão interna</p>
        </div>
      </footer>
    </div>
  );
}
